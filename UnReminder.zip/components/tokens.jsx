// Design tokens for UnReminder
// Kinetic & playful: a palette wheel + type stack + glyph rotation

const PALETTES = [
  { name: 'sage',   bg: '#e8ebd9', ink: '#1f2a1a', accent: '#4d6b3a', soft: '#cfd7b8', tag: 'Sage' },
  { name: 'clay',   bg: '#f3dccb', ink: '#2a1a12', accent: '#a8502a', soft: '#e4b9a0', tag: 'Clay' },
  { name: 'lilac',  bg: '#e4dcec', ink: '#1e1a2a', accent: '#6c4d9c', soft: '#cfc2de', tag: 'Lilac' },
  { name: 'butter', bg: '#f3e8b4', ink: '#2a2410', accent: '#9a7a15', soft: '#e4d684', tag: 'Butter' },
  { name: 'ink',    bg: '#1a1c20', ink: '#f2ede1', accent: '#d4b37a', soft: '#2d3138', tag: 'Ink' },
  { name: 'peach',  bg: '#ffd9c2', ink: '#2b150a', accent: '#c44a1a', soft: '#ffbea0', tag: 'Peach' },
  { name: 'mint',   bg: '#cee8db', ink: '#0f2018', accent: '#1f7a55', soft: '#a8d1bd', tag: 'Mint' },
  { name: 'rose',   bg: '#f2cfd4', ink: '#2a0f14', accent: '#a83248', soft: '#e4a7b0', tag: 'Rose' },
];

const DARK_PALETTES = [
  { name: 'sage-d',   bg: '#171c14', ink: '#e0e8cc', accent: '#a8c485', soft: '#252d1f', tag: 'Sage' },
  { name: 'clay-d',   bg: '#1c1410', ink: '#f3dccb', accent: '#e08a5a', soft: '#2a1e18', tag: 'Clay' },
  { name: 'lilac-d',  bg: '#15131c', ink: '#dcd0ec', accent: '#b695e0', soft: '#231f2e', tag: 'Lilac' },
  { name: 'butter-d', bg: '#1c1a10', ink: '#f3e8b4', accent: '#e4c75a', soft: '#2a2618', tag: 'Butter' },
  { name: 'ink-d',    bg: '#0f1114', ink: '#e8e2d4', accent: '#d4b37a', soft: '#1e2228', tag: 'Ink' },
  { name: 'peach-d',  bg: '#1c1410', ink: '#ffd9c2', accent: '#ff8a5a', soft: '#2a1e18', tag: 'Peach' },
  { name: 'mint-d',   bg: '#0f1816', ink: '#cee8db', accent: '#7cc9a6', soft: '#1a2522', tag: 'Mint' },
  { name: 'rose-d',   bg: '#1c1014', ink: '#f2cfd4', accent: '#e07a8e', soft: '#2a181e', tag: 'Rose' },
];

// Seed glyphs — small geometric marks that rotate per notification
// Each takes {size, color} and returns an SVG
const SeedGlyph = ({ kind, size = 32, color = 'currentColor' }) => {
  const s = size;
  switch (kind) {
    case 'circle':
      return <svg width={s} height={s} viewBox="0 0 32 32"><circle cx="16" cy="16" r="10" stroke={color} strokeWidth="2" fill="none"/></svg>;
    case 'arch':
      return <svg width={s} height={s} viewBox="0 0 32 32"><path d="M6 26 V16 a10 10 0 0 1 20 0 V26" stroke={color} strokeWidth="2" fill="none"/></svg>;
    case 'square':
      return <svg width={s} height={s} viewBox="0 0 32 32"><rect x="7" y="7" width="18" height="18" stroke={color} strokeWidth="2" fill="none" transform="rotate(12 16 16)"/></svg>;
    case 'tri':
      return <svg width={s} height={s} viewBox="0 0 32 32"><path d="M16 6 L26 24 L6 24 Z" stroke={color} strokeWidth="2" fill="none"/></svg>;
    case 'bars':
      return <svg width={s} height={s} viewBox="0 0 32 32"><rect x="7" y="10" width="3" height="14" fill={color}/><rect x="14.5" y="6" width="3" height="18" fill={color}/><rect x="22" y="14" width="3" height="10" fill={color}/></svg>;
    case 'ring':
      return <svg width={s} height={s} viewBox="0 0 32 32"><circle cx="16" cy="16" r="10" stroke={color} strokeWidth="2" fill="none"/><circle cx="16" cy="16" r="3" fill={color}/></svg>;
    case 'dot':
      return <svg width={s} height={s} viewBox="0 0 32 32"><circle cx="16" cy="16" r="5" fill={color}/></svg>;
    case 'cross':
      return <svg width={s} height={s} viewBox="0 0 32 32"><path d="M9 9 L23 23 M23 9 L9 23" stroke={color} strokeWidth="2"/></svg>;
    case 'wave':
      return <svg width={s} height={s} viewBox="0 0 32 32"><path d="M4 16 Q10 8 16 16 T28 16" stroke={color} strokeWidth="2" fill="none"/></svg>;
    case 'slash':
      return <svg width={s} height={s} viewBox="0 0 32 32"><path d="M8 24 L24 8" stroke={color} strokeWidth="2.5"/><circle cx="24" cy="8" r="2" fill={color}/></svg>;
    default:
      return null;
  }
};

// Fonts — CSS variables
const FONT_DISPLAY = "'Instrument Serif', 'Cormorant Garamond', Georgia, serif";
const FONT_SANS = "'Geist', 'Inter', system-ui, sans-serif"; // Geist preferred
const FONT_MONO = "'JetBrains Mono', 'Geist Mono', ui-monospace, monospace";

Object.assign(window, { PALETTES, DARK_PALETTES, SeedGlyph, FONT_DISPLAY, FONT_SANS, FONT_MONO });
