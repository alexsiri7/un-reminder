// Screen 02 — Habit Editor with AI autofill
// Shows: name input, AI-generated descriptions (full + low-floor), location chips,
// active toggle, Preview notification button

function HabitEditorScreen({ palette, dark, FONT_DISPLAY, FONT_SANS, FONT_MONO }) {
  const p = palette;
  return (
    <div style={{
      background: p.bg, color: p.ink, height: '100%',
      fontFamily: FONT_SANS, display: 'flex', flexDirection: 'column',
    }}>
      {/* Status bar */}
      <div style={{
        height: 40, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '0 20px', fontFamily: FONT_MONO, fontSize: 13, opacity: 0.8,
      }}>
        <span>9:31</span>
        <span style={{ fontSize: 11, letterSpacing: 1 }}>◐ offline</span>
      </div>

      {/* Top bar */}
      <div style={{
        padding: '8px 16px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ fontFamily: FONT_MONO, fontSize: 14, opacity: 0.7 }}>← back</div>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 2,
          textTransform: 'uppercase', opacity: 0.55,
        }}>editing</div>
        <div style={{ fontFamily: FONT_MONO, fontSize: 14, fontWeight: 600, color: p.accent }}>save</div>
      </div>

      {/* Title */}
      <div style={{ padding: '20px 24px 8px' }}>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
          textTransform: 'uppercase', opacity: 0.55, marginBottom: 8,
        }}>habit name</div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 44, lineHeight: 1,
          letterSpacing: -0.5,
          borderBottom: `2px solid ${p.accent}`,
          paddingBottom: 6,
        }}>
          meditation<span style={{ color: p.accent, opacity: 0.5, marginLeft: 2 }}>|</span>
        </div>
      </div>

      {/* AI assist row */}
      <div style={{
        margin: '16px 20px 0', padding: '14px 16px',
        background: p.soft, borderRadius: 2,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 1.5,
            textTransform: 'uppercase', opacity: 0.65, marginBottom: 2,
          }}>gemma · on-device</div>
          <div style={{ fontFamily: FONT_SANS, fontSize: 13, fontWeight: 500 }}>
            Autofill descriptions
          </div>
        </div>
        <div style={{
          padding: '8px 14px', background: p.accent, color: p.bg,
          fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 1,
          textTransform: 'uppercase', borderRadius: 2, fontWeight: 600,
        }}>
          ✦ autofill
        </div>
      </div>

      {/* Descriptions */}
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{ marginBottom: 16 }}>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
            textTransform: 'uppercase', opacity: 0.55, marginBottom: 6,
            display: 'flex', justifyContent: 'space-between',
          }}>
            <span>full version</span>
            <span style={{ color: p.accent }}>✦ filled</span>
          </div>
          <div style={{
            fontFamily: FONT_DISPLAY, fontSize: 22, lineHeight: 1.2,
            fontStyle: 'italic',
          }}>20-minute guided body-scan meditation</div>
        </div>

        <div>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
            textTransform: 'uppercase', opacity: 0.55, marginBottom: 6,
            display: 'flex', justifyContent: 'space-between',
          }}>
            <span>low-floor · counts as a win</span>
            <span style={{ color: p.accent }}>✦ filled</span>
          </div>
          <div style={{
            fontFamily: FONT_DISPLAY, fontSize: 22, lineHeight: 1.2,
            fontStyle: 'italic',
          }}>3 deep breaths</div>
        </div>
      </div>

      {/* Locations */}
      <div style={{ padding: '24px 24px 0' }}>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
          textTransform: 'uppercase', opacity: 0.55, marginBottom: 10,
        }}>eligible at</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {[
            { label: 'Home', on: true },
            { label: 'Office', on: false },
            { label: 'Gym', on: false },
            { label: 'Anywhere', on: false, muted: true },
          ].map(c => (
            <div key={c.label} style={{
              padding: '8px 14px', borderRadius: 2,
              border: `1.5px solid ${c.on ? p.accent : p.ink + '30'}`,
              background: c.on ? p.accent : 'transparent',
              color: c.on ? p.bg : p.ink,
              fontFamily: FONT_SANS, fontSize: 13, fontWeight: 500,
              opacity: c.muted ? 0.5 : 1,
              fontStyle: c.muted ? 'italic' : 'normal',
            }}>{c.label}</div>
          ))}
        </div>
      </div>

      {/* Preview */}
      <div style={{ padding: '24px 20px 0', flex: 1 }}>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
          textTransform: 'uppercase', opacity: 0.55, marginBottom: 10,
          paddingLeft: 4,
        }}>preview · sampled from gemma</div>
        <div style={{
          padding: '16px 18px', background: p.ink, color: p.bg,
          borderRadius: 2, position: 'relative',
        }}>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 9.5, letterSpacing: 1,
            opacity: 0.55, marginBottom: 6,
          }}>UN-REMINDER · now</div>
          <div style={{
            fontFamily: FONT_DISPLAY, fontSize: 20, lineHeight: 1.2, fontStyle: 'italic',
          }}>Settle for a moment — three slow breaths is enough.</div>
          <div style={{
            position: 'absolute', top: 14, right: 14,
            fontFamily: FONT_MONO, fontSize: 10, opacity: 0.6,
          }}>↻ resample</div>
        </div>
      </div>

      {/* Bottom: active + danger */}
      <div style={{
        padding: '16px 20px 14px',
        borderTop: `1px solid ${p.soft}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 40, height: 22, borderRadius: 12,
            background: p.accent, position: 'relative',
          }}>
            <div style={{
              position: 'absolute', right: 2, top: 2, width: 18, height: 18,
              borderRadius: '50%', background: p.bg,
            }} />
          </div>
          <span style={{ fontFamily: FONT_SANS, fontSize: 13, fontWeight: 500 }}>Active</span>
        </div>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 11, opacity: 0.5,
          textDecoration: 'underline',
        }}>delete habit</div>
      </div>

      <div style={{ height: 20, display: 'grid', placeItems: 'center' }}>
        <div style={{ width: 108, height: 4, borderRadius: 2, background: p.ink, opacity: 0.3 }} />
      </div>
    </div>
  );
}

window.HabitEditorScreen = HabitEditorScreen;
