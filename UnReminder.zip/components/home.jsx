// Screen 01 — Home / Habit list
// A warm "today" view. Not a tracker — no streaks, no counts.
// Shows: current context strip, active habits grouped by location,
// and a subtle hint of the next window.

function HomeScreen({ palette, dark, FONT_DISPLAY, FONT_SANS, FONT_MONO }) {
  const p = palette;
  const habits = [
    { name: 'meditation',       low: '3 deep breaths',       locs: ['Home'],        active: true,  glyph: 'arch' },
    { name: 'gratefulness',     low: '1 mental thank-you',   locs: [],              active: true,  glyph: 'ring' },
    { name: 'singing practice', low: 'hum 8 bars',           locs: ['Home'],        active: true,  glyph: 'wave' },
    { name: 'stretching',       low: 'reach for the ceiling',locs: ['Office'],      active: true,  glyph: 'bars' },
    { name: 'water',            low: 'one sip',              locs: [],              active: true,  glyph: 'dot' },
    { name: 'posture check',    low: 'roll shoulders back',  locs: ['Office','Home'],active: false, glyph: 'slash' },
  ];

  return (
    <div style={{
      background: p.bg, color: p.ink, height: '100%',
      fontFamily: FONT_SANS, display: 'flex', flexDirection: 'column',
    }}>
      {/* Status bar */}
      <div style={{
        height: 40, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '0 20px', fontFamily: FONT_MONO, fontSize: 13, color: p.ink, opacity: 0.8,
      }}>
        <span>9:30</span>
        <span style={{ fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 1 }}>◐ offline</span>
      </div>

      {/* Header — big serif mark */}
      <div style={{ padding: '20px 24px 12px' }}>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2, textTransform: 'uppercase',
          opacity: 0.6, marginBottom: 6,
        }}>
          ── wed · apr 18 · evening ──
        </div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 52, lineHeight: 0.95,
          letterSpacing: -1, fontStyle: 'italic',
        }}>
          un-<span style={{ fontStyle: 'normal' }}>reminder</span>
        </div>
      </div>

      {/* Context strip */}
      <div style={{
        margin: '12px 16px', padding: '12px 16px',
        background: p.soft, borderRadius: 2,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 0.5,
      }}>
        <div>
          <div style={{ opacity: 0.6, marginBottom: 2, fontSize: 10 }}>YOU ARE AT</div>
          <div style={{ fontSize: 14, fontFamily: FONT_SANS, fontWeight: 500, letterSpacing: 0 }}>Home</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ opacity: 0.6, marginBottom: 2, fontSize: 10 }}>NEXT WINDOW</div>
          <div style={{ fontSize: 14, fontFamily: FONT_SANS, fontWeight: 500, letterSpacing: 0 }}>evening · 18–21</div>
        </div>
      </div>

      {/* List header */}
      <div style={{
        padding: '16px 24px 8px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
      }}>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 1.5,
          textTransform: 'uppercase', opacity: 0.65,
        }}>5 habits, eligible now</div>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 11, opacity: 0.5,
        }}>{'+ new'}</div>
      </div>

      {/* Habit rows */}
      <div style={{ flex: 1, padding: '0 8px', overflow: 'auto' }}>
        {habits.map((h, i) => (
          <div key={h.name} style={{
            padding: '14px 16px',
            borderBottom: `1px solid ${p.soft}`,
            display: 'flex', alignItems: 'center', gap: 14,
            opacity: h.active ? 1 : 0.35,
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: '50%',
              background: p.soft, display: 'grid', placeItems: 'center',
              color: p.accent, flexShrink: 0,
            }}>
              <SeedGlyph kind={h.glyph} size={22} color={p.accent} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: FONT_DISPLAY, fontSize: 22, lineHeight: 1.1,
                letterSpacing: -0.3, textDecoration: h.active ? 'none' : 'line-through',
              }}>{h.name}</div>
              <div style={{
                fontFamily: FONT_MONO, fontSize: 11, opacity: 0.65,
                marginTop: 2, letterSpacing: 0.2,
              }}>
                floor: {h.low}
              </div>
            </div>
            <div style={{
              fontFamily: FONT_MONO, fontSize: 9.5, letterSpacing: 1,
              textTransform: 'uppercase', opacity: 0.55,
              padding: '3px 6px',
              border: `1px solid ${p.ink}20`, borderRadius: 2,
            }}>
              {h.locs.length === 0 ? 'anywhere' : h.locs.join(' · ')}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom — FAB-ish + footer */}
      <div style={{
        padding: '12px 20px 14px',
        borderTop: `1px solid ${p.soft}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: p.bg,
      }}>
        <div style={{ display: 'flex', gap: 18, fontFamily: FONT_MONO, fontSize: 11, opacity: 0.7 }}>
          <span style={{ fontWeight: 700, color: p.accent }}>habits</span>
          <span>windows</span>
          <span>places</span>
          <span>recent</span>
        </div>
        <div style={{
          width: 44, height: 44, borderRadius: '50%',
          background: p.accent, color: p.bg,
          display: 'grid', placeItems: 'center',
          fontFamily: FONT_DISPLAY, fontSize: 28, lineHeight: 1,
          boxShadow: `0 2px 0 ${p.ink}30`,
        }}>+</div>
      </div>

      {/* Nav pill */}
      <div style={{ height: 20, display: 'grid', placeItems: 'center' }}>
        <div style={{ width: 108, height: 4, borderRadius: 2, background: p.ink, opacity: 0.3 }} />
      </div>
    </div>
  );
}

window.HomeScreen = HomeScreen;
