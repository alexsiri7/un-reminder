// Screen 03 — Notification Moments (lock screen)
// 6 variants showing how the system defeats blindness via
// shifting color, type, layout, and glyph per fire.

function LockScreen({ palette: p, variant, prompt, habit, time, context, location, FONT_DISPLAY, FONT_SANS, FONT_MONO }) {
  // Layout variants
  // 1 - centered-question (big italic serif, glyph above)
  // 2 - off-center-asymmetric (type flush-left big, glyph top-right)
  // 3 - full-bleed-type (massive display serif, breaks margins)
  // 4 - bottom-anchored-card (card notification, old-school but re-skinned)
  // 5 - mono-terse (all mono, curt imperative)
  // 6 - arrival (with location chip, different frame)

  const MetaStrip = () => (
    <div style={{
      fontFamily: FONT_MONO, fontSize: 9.5, letterSpacing: 1.5,
      textTransform: 'uppercase', opacity: 0.7,
      display: 'flex', justifyContent: 'space-between',
    }}>
      <span>un-reminder</span>
      <span>{context || 'window'} · {p.tag}</span>
    </div>
  );

  const Actions = ({ inverse }) => (
    <div style={{
      display: 'flex', gap: 8, marginTop: 16,
    }}>
      {[
        { l: 'did it', primary: true },
        { l: 'tiny', primary: false },
        { l: '—', primary: false },
      ].map(a => (
        <div key={a.l} style={{
          flex: a.l === '—' ? 0 : 1,
          padding: '10px 14px',
          background: a.primary ? (inverse ? p.bg : p.accent) : 'transparent',
          color: a.primary ? (inverse ? p.ink : p.bg) : (inverse ? p.bg : p.ink),
          border: a.primary ? 'none' : `1px solid ${(inverse ? p.bg : p.ink)}40`,
          fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 1,
          textTransform: 'uppercase', textAlign: 'center', fontWeight: 600,
          borderRadius: 2, minWidth: a.l === '—' ? 44 : 'auto',
        }}>{a.l}</div>
      ))}
    </div>
  );

  // Shared lock-screen chrome
  const Chrome = ({ children, contentBg }) => (
    <div style={{
      background: p.bg, color: p.ink, height: '100%',
      fontFamily: FONT_SANS, display: 'flex', flexDirection: 'column',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* faux lock screen top */}
      <div style={{
        height: 40, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '0 20px', fontFamily: FONT_MONO, fontSize: 13, opacity: 0.7,
      }}>
        <span>{time}</span>
        <span style={{ fontSize: 10, letterSpacing: 1.5 }}>◐ offline</span>
      </div>

      {/* clock */}
      <div style={{ textAlign: 'center', padding: '24px 0 12px' }}>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 70, lineHeight: 0.9, letterSpacing: -2,
          fontWeight: 300,
        }}>{time}</div>
        <div style={{
          fontFamily: FONT_MONO, fontSize: 11, letterSpacing: 2,
          textTransform: 'uppercase', opacity: 0.65, marginTop: 4,
        }}>wed · apr 18</div>
      </div>

      {/* notification area */}
      <div style={{ flex: 1, padding: '8px 12px', display: 'flex', alignItems: 'flex-end' }}>
        {children}
      </div>

      <div style={{ height: 20, display: 'grid', placeItems: 'center', paddingBottom: 8 }}>
        <div style={{ width: 108, height: 4, borderRadius: 2, background: p.ink, opacity: 0.3 }} />
      </div>
    </div>
  );

  // ─────────── Variant 1: Centered Question ───────────
  if (variant === 1) return (
    <Chrome>
      <div style={{
        width: '100%', background: p.soft, padding: '22px 20px 18px',
        borderRadius: 2, textAlign: 'center',
      }}>
        <div style={{ display: 'grid', placeItems: 'center', marginBottom: 14 }}>
          <SeedGlyph kind="ring" size={40} color={p.accent} />
        </div>
        <MetaStrip />
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 26, lineHeight: 1.15,
          fontStyle: 'italic', letterSpacing: -0.3,
          margin: '14px 8px 0',
        }}>{prompt}</div>
        <Actions />
      </div>
    </Chrome>
  );

  // ─────────── Variant 2: Off-center asymmetric ───────────
  if (variant === 2) return (
    <Chrome>
      <div style={{
        width: '100%', background: p.soft, padding: '22px 20px 18px',
        borderRadius: 2, position: 'relative',
      }}>
        <div style={{ position: 'absolute', top: 18, right: 18 }}>
          <SeedGlyph kind="bars" size={34} color={p.accent} />
        </div>
        <MetaStrip />
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 30, lineHeight: 1.05,
          letterSpacing: -0.5,
          marginTop: 18, paddingRight: 44, fontWeight: 400,
        }}>{prompt}</div>
        <div style={{
          marginTop: 10, fontFamily: FONT_MONO, fontSize: 10,
          letterSpacing: 1, opacity: 0.6, textTransform: 'uppercase',
        }}>habit · {habit}</div>
        <Actions />
      </div>
    </Chrome>
  );

  // ─────────── Variant 3: Full-bleed display type ───────────
  if (variant === 3) return (
    <Chrome>
      <div style={{
        width: '100%', background: p.accent, color: p.bg,
        padding: '24px 18px 18px',
        borderRadius: 2, position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 9.5, letterSpacing: 1.5,
            textTransform: 'uppercase', opacity: 0.85,
          }}>un-reminder · now</div>
          <SeedGlyph kind="slash" size={28} color={p.bg} />
        </div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 44, lineHeight: 0.95,
          letterSpacing: -1.5, marginTop: 16, fontWeight: 400,
        }}>{prompt}</div>
        <div style={{
          marginTop: 14, fontFamily: FONT_MONO, fontSize: 10,
          letterSpacing: 1, opacity: 0.8, textTransform: 'uppercase',
        }}>{habit} · floor is enough</div>
        <Actions inverse />
      </div>
    </Chrome>
  );

  // ─────────── Variant 4: Bottom-anchored card (familiar) ───────────
  if (variant === 4) return (
    <Chrome>
      <div style={{
        width: '100%', background: p.ink, color: p.bg,
        padding: '18px 18px 16px',
        borderRadius: 2,
        display: 'flex', gap: 14,
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: '50%',
          background: p.accent, display: 'grid', placeItems: 'center',
          flexShrink: 0,
        }}>
          <SeedGlyph kind="wave" size={26} color={p.bg} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: FONT_MONO, fontSize: 9.5, letterSpacing: 1.5,
            textTransform: 'uppercase', opacity: 0.6, marginBottom: 4,
            display: 'flex', justifyContent: 'space-between',
          }}>
            <span>un-reminder</span><span>9:47 pm</span>
          </div>
          <div style={{
            fontFamily: FONT_SANS, fontSize: 15, lineHeight: 1.3, fontWeight: 500,
          }}>{prompt}</div>
          <Actions inverse />
        </div>
      </div>
    </Chrome>
  );

  // ─────────── Variant 5: Mono-terse imperative ───────────
  if (variant === 5) return (
    <Chrome>
      <div style={{
        width: '100%', background: p.bg, padding: '22px 20px 18px',
        border: `2px solid ${p.ink}`, borderRadius: 2, position: 'relative',
      }}>
        <div style={{
          position: 'absolute', top: -11, left: 16,
          background: p.bg, padding: '0 8px',
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 2,
          textTransform: 'uppercase',
        }}>un-reminder / {p.tag.toLowerCase()}</div>
        <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
          <div style={{ paddingTop: 4 }}>
            <SeedGlyph kind="cross" size={30} color={p.ink} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{
              fontFamily: FONT_MONO, fontSize: 18, lineHeight: 1.3,
              letterSpacing: -0.2, fontWeight: 500,
            }}>{prompt}</div>
          </div>
        </div>
        <Actions />
      </div>
    </Chrome>
  );

  // ─────────── Variant 6: Arrival trigger (geofence) ───────────
  if (variant === 6) return (
    <Chrome>
      <div style={{
        width: '100%', padding: '22px 20px 18px',
        background: p.bg, border: `1px dashed ${p.accent}`,
        borderRadius: 2, position: 'relative',
      }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          marginBottom: 12,
        }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            fontFamily: FONT_MONO, fontSize: 10, letterSpacing: 1.5,
            textTransform: 'uppercase', padding: '3px 8px',
            background: p.accent, color: p.bg, borderRadius: 2,
          }}>◉ arrived at {location}</div>
          <SeedGlyph kind="arch" size={30} color={p.accent} />
        </div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 26, lineHeight: 1.1,
          fontStyle: 'italic', letterSpacing: -0.3,
        }}>{prompt}</div>
        <div style={{
          marginTop: 8, fontFamily: FONT_MONO, fontSize: 10,
          letterSpacing: 1, opacity: 0.6, textTransform: 'uppercase',
        }}>{habit} · 5 min after arrival</div>
        <Actions />
      </div>
    </Chrome>
  );

  return null;
}

window.LockScreen = LockScreen;
